﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement Controls")]
    public float movementSpeed = 1f;
    public float JumpForce = 250f;
    public bool isGrounded;

    [Header("GameObject Components")]
    public Rigidbody rb;



    public void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
    }

    public void FixedUpdate()
    {
        Movement();
    }

    void Movement()
    {
        if (Input.GetAxis("Horizontal") > 0)
        {
            rb.velocity = new Vector3(movementSpeed, 0, 0);
        }

        if (Input.GetAxis("Horizontal") < 0)
        {
            rb.velocity = new Vector3(-movementSpeed, 0, 0);
        }

        if (Input.GetAxis("Vertical") > 0)
        {
            rb.velocity = new Vector3(0, 0, movementSpeed);
        }

        if (Input.GetAxis("Vertical") < 0)
        {
            rb.velocity = new Vector3(0, 0, -movementSpeed);
        }

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            rb.AddForce(0, JumpForce, 0);
            isGrounded = false;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<SolidSurface>())
        {
            Debug.Log("Eat ass");
            isGrounded = true;
        }
    }

}
